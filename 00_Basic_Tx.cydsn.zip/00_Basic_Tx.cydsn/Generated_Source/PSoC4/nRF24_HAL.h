/**
* @file     nRF24_HAL.h
* @version  3
*/

#ifndef nRF24_HAL_H
#define nRF24_HAL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>

#include "nRF24_DEFS.h"

/* SPI */
void nRF24_spi_xfer(const uint8_t *in, uint8_t *out, const size_t xfer_size);

// 3.0
uint8_t nRF24_read_reg(const nrf_register reg, uint8_t *data, const size_t data_size);
uint8_t nRF24_write_reg(const nrf_register reg, const uint8_t *data, const size_t data_size);
bool nRF24_read_bit(const nrf_register reg, const uint8_t bit_pos);
void nRF24_clear_bit(const nrf_register reg, const uint8_t bit_pos);
void nRF24_set_bit(const nrf_register reg, const uint8_t bit_pos);

/* GPIO Control */

typedef enum {
    GPIO_CLEAR,
    GPIO_SET
} nrf_gpio;

void nRF24_ss_write(nrf_gpio state);
void nRF24_ce_write(nrf_gpio state);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* nRF24_HAL_H */

/* [] END OF FILE */
