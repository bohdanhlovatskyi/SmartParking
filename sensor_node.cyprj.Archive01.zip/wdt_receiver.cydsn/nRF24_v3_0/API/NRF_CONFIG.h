/**
* @file     `$INSTANCE_NAME`_CONFIG.h
* @version  3
* @brief    Configuration file.
*/

#ifndef `$INSTANCE_NAME`_CONFIG_H
#define `$INSTANCE_NAME`_CONFIG_H

#include "`$SPI_MASTER`.h"

/* So there's no symbol to know if the API is being built
 * for a psoc4, 5lp or 6, so i found out based on the spi headers */
#if defined (CY_SCB_`$SPI_MASTER`_H)
# if defined (`$SPI_MASTER`_CY_SCB_SPI_PDL_H)
#  define _PSOC6
# else
#  define _PSOC4_SCB
   #include "`$SPI_MASTER`_SPI_UART.h"
# endif
#else
# define _PSOC_UDB
#endif

#include "`$INSTANCE_NAME`_DEFS.h"

// Component version info
#define `$INSTANCE_NAME`_VERSION_MAJOR  `=$CY_MAJOR_VERSION`
#define `$INSTANCE_NAME`_VERSION_MINOR  `=$CY_MINOR_VERSION`
#define `$INSTANCE_NAME`_VERSION        `=$CY_MAJOR_VERSION`.`=$CY_MINOR_VERSION`

// Data from customizer
#define ENABLE_PIPE0    `@ERX_P0`
#define ENABLE_PIPE1    `@ERX_P1`
#define ENABLE_PIPE2    `@ERX_P2`
#define ENABLE_PIPE3    `@ERX_P3`
#define ENABLE_PIPE4    `@ERX_P4`
#define ENABLE_PIPE5    `@ERX_P5`

#define CUSTOMIZER_EN_AA        ((`$ENAA_P5` << NRF_EN_AA_BIT_ENAA_P5) | (`$ENAA_P4` << NRF_EN_AA_BIT_ENAA_P4) | \
                                (`$ENAA_P3` << NRF_EN_AA_BIT_ENAA_P3) | (`$ENAA_P2` << NRF_EN_AA_BIT_ENAA_P2) | \
                                (`$ENAA_P1` << NRF_EN_AA_BIT_ENAA_P1) | (`$ENAA_P0` << NRF_EN_AA_BIT_ENAA_P0))
#define CUSTOMIZER_EN_RXADDR    ((`$ERX_P5` << NRF_EN_RXADDR_BIT_ERX_P5) | (`$ERX_P4` << NRF_EN_RXADDR_BIT_ERX_P4) | \
                                (`$ERX_P3` << NRF_EN_RXADDR_BIT_ERX_P3) | (`$ERX_P2` << NRF_EN_RXADDR_BIT_ERX_P2) | \
                                (`$ERX_P1` << NRF_EN_RXADDR_BIT_ERX_P1) | (`$ERX_P0` << NRF_EN_RXADDR_BIT_ERX_P0))
#define CUSTOMIZER_SETUP_AW     (`$AW`)
#define CUSTOMIZER_SETUP_RETR   ((`$ARD` << NRF_SETUP_RETR_BIT_ARD) | (`$ARC` << NRF_SETUP_RETR_BIT_ARC))
#define CUSTOMIZER_RF_CH        (`$RF_CH`)
#define CUSTOMIZER_RF_SETUP     ((`$CONT_WAVE` << NRF_RF_SETUP_BIT_CONT_WAVE) | (`$RF_DATA_RATE` << NRF_RF_SETUP_BIT_RF_DR) | \
                                (`$RF_PWR` << NRF_RF_SETUP_BIT_RF_PWR))
#define CUSTOMIZER_DYNPD        ((`$DPL_P5` << NRF_DYNPD_BIT_DPL_P5) | (`$DPL_P4` << NRF_DYNPD_BIT_DPL_P4) | \
                                (`$DPL_P3` << NRF_DYNPD_BIT_DPL_P3) | (`$DPL_P2` << NRF_DYNPD_BIT_DPL_P2) | \
                                (`$DPL_P1` << NRF_DYNPD_BIT_DPL_P1) | (`$DPL_P0` << NRF_DYNPD_BIT_DPL_P0))
#define CUSTOMIZER_FEATURE      ((`$EN_DPL` << NRF_FEATURE_BIT_EN_DPL) | (`$EN_ACK_PAY` << NRF_FEATURE_BIT_EN_ACK_PAY) | \
                                (`$EN_DYN_ACK` << NRF_FEATURE_BIT_EN_DYN_ACK))
#define CUSTOMIZER_CONFIG       ((`$MASK_RX_DR` << NRF_CONFIG_BIT_MASK_RX_DR) | (`$MASK_TX_DS` << NRF_CONFIG_BIT_MASK_TX_DS) | \
                                (`$MASK_MAX_RT` << NRF_CONFIG_BIT_MASK_MAX_RT) | (`$EN_CRC` << NRF_CONFIG_BIT_EN_CRC) | \
                                (`$CRCO` << NRF_CONFIG_BIT_CRCO) | (`$PWR_UP`<< NRF_CONFIG_BIT_PWR_UP) | (`$PRIM_RX` << NRF_CONFIG_BIT_PRIM_RX))
#define CUSTOMIZER_RX_PW_P0     (`@RX_PW_P0`)
#define CUSTOMIZER_RX_PW_P1     (`@RX_PW_P1`)
#define CUSTOMIZER_RX_PW_P2     (`@RX_PW_P2`)
#define CUSTOMIZER_RX_ADDR_P2   (`@RX_ADDR_P2`)
#define CUSTOMIZER_RX_PW_P3     (`@RX_PW_P3`)
#define CUSTOMIZER_RX_ADDR_P3   (`@RX_ADDR_P3`)
#define CUSTOMIZER_RX_PW_P4     (`@RX_PW_P4`)
#define CUSTOMIZER_RX_ADDR_P4   (`@RX_ADDR_P4`)
#define CUSTOMIZER_RX_PW_P5     (`@RX_PW_P5`)
#define CUSTOMIZER_RX_ADDR_P5   (`@RX_ADDR_P5`)

#endif /* `$INSTANCE_NAME`_CONFIG_H */

/* [] END OF FILE */
