/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <stdbool.h>

#define HMC5883L 0x1E
#define MAXLEN 32
#define SENSORS_GAUSS_TO_MICROTESLA (100)

enum {
  HMC5883_REGISTER_MAG_CRA_REG_M = 0x00,
  HMC5883_REGISTER_MAG_CRB_REG_M = 0x01,
  HMC5883_REGISTER_MAG_MR_REG_M = 0x02,
  HMC5883_REGISTER_MAG_OUT_X_H_M = 0x03,
  HMC5883_REGISTER_MAG_OUT_X_L_M = 0x04,
  HMC5883_REGISTER_MAG_OUT_Z_H_M = 0x05,
  HMC5883_REGISTER_MAG_OUT_Z_L_M = 0x06,
  HMC5883_REGISTER_MAG_OUT_Y_H_M = 0x07,
  HMC5883_REGISTER_MAG_OUT_Y_L_M = 0x08,
  HMC5883_REGISTER_MAG_SR_REG_Mg = 0x09,
  HMC5883_REGISTER_MAG_IRA_REG_M = 0x0A,
  HMC5883_REGISTER_MAG_IRB_REG_M = 0x0B,
  HMC5883_REGISTER_MAG_IRC_REG_M = 0x0C,
  HMC5883_REGISTER_MAG_TEMP_OUT_H_M = 0x31,
  HMC5883_REGISTER_MAG_TEMP_OUT_L_M = 0x32
};


// interupt for the nrf module
volatile bool irq_flag = false;

static float _hmc5883_Gauss_LSB_XY = 1100.0F; // Varies with gain
static float _hmc5883_Gauss_LSB_Z = 980.0F;   // Varies with gain

void Read_Mag(uint8_t *magData);
// the IRQ pin triggered an interrupt
CY_ISR_PROTO(IRQ_Handler);

int main(void)
{
    uint8_t mag[3] = {0};
    const uint8_t TX_ADDR[5]= {0xBA, 0xAD, 0xC0, 0xFF, 0xEE};

    CyGlobalIntEnable; /* Enable global interrupts. */
    
    // Set the interrupts handlers
    isr_IRQ_StartEx(IRQ_Handler);

    nRF24_start();
    nRF24_set_channel(5);
    nRF24_set_rx_pipe_address(NRF_ADDR_PIPE0, TX_ADDR, 5);
    // set tx pipe address to match the receiver address
    nRF24_set_tx_address(TX_ADDR, 5);

    I2C_Start(); 
    
    I2C_I2CMasterSendStart(HMC5883L, I2C_I2C_WRITE_XFER_MODE, 100);
    I2C_I2CMasterWriteByte(HMC5883_REGISTER_MAG_MR_REG_M, 100);
    // required bits in the register
    I2C_I2CMasterWriteByte(0x00u, 100);
    I2C_I2CMasterSendStop(50);
    
    Pin_Red_Write(1);
    CyDelay( 1000 );
    Pin_Red_Write(0);
 
    for(;;)
    {
        // I2C_MasterRead(HMC5883L, MAXLEN, i2cbuf);
        // sprintf(msg, "%s\r\n", i2cbuf);
        // memset(msg, 0, sizeof(msg)); 
        Pin_Red_Write(0);
        Read_Mag(mag);

        nRF24_transmit(mag, sizeof(mag));
        LED_Write(0);
        CyDelay(50);
        LED_Write(1);
        
        // print_status();
        while(false == irq_flag);
            
        // Get and clear the flag that caused the IRQ interrupt,
        // in this project the only IRQ cause is the caused by
        // transmitting data (NRF_STATUS_TX_DS_MASK) or timeout
        nrf_irq flag = nRF24_get_irq_flag();
        
        switch (flag) {
        case NRF_TX_DS_IRQ:
            // turn on the Green LED if the transmit was successfull
            LED_Write(0);
            break;
        case NRF_MAX_RT_IRQ:
            // turn off the Green LED if the transmit was not successfull
            LED_Write(1);
            break;
        default:
            break;
        }
        
        nRF24_clear_irq_flag(flag);
        
        irq_flag = false;
        
        CyDelay(250);
    }
}

void Read_Mag(uint8_t *magData) {
    uint8 data[6];
    
    I2C_I2CMasterSendStart(HMC5883L, I2C_I2C_WRITE_XFER_MODE, 100);
    I2C_I2CMasterWriteByte(HMC5883_REGISTER_MAG_OUT_X_H_M, 100);
    
    I2C_I2CMasterSendStop(50);
    
    I2C_I2CMasterSendStart(HMC5883L, I2C_I2C_READ_XFER_MODE, 50);
    
    int i = 0;
    for (; i < 5; i++) {
        I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA, &data[i], 50); 
    }
    I2C_I2CMasterReadByte(I2C_I2C_NAK_DATA, &data[++i], 50);
    I2C_I2CMasterSendStop(50);
    
    int x = (data[1] | (data[0] << 8));
    int y = (data[5] | (data[4] << 8));
    int z = (data[3] | (data[2] << 8));
    
    magData[0] = x / _hmc5883_Gauss_LSB_XY * SENSORS_GAUSS_TO_MICROTESLA;
    magData[1] = y / _hmc5883_Gauss_LSB_XY * SENSORS_GAUSS_TO_MICROTESLA;
    magData[2] = z / _hmc5883_Gauss_LSB_Z * SENSORS_GAUSS_TO_MICROTESLA;
    
}


CY_ISR(IRQ_Handler)
{
    irq_flag = true;
    IRQ_ClearInterrupt();
}
